// Class: CSE 1321L
// Section:09
// Term:Fall 
// Instructor:Shweta Khandal 
// Name:Rutvik Marakana 
// Lab#:Java
 
class Favorites
{
   public static void main(String [] args)
   {
        System.out.println("My name: Rutvik Marakana");
        System.out.println("My birthday: 10/12/1999");
        System.out.println("My hobbies: Reading, Cycling, Studying");
        System.out.println("My favorite book: Five point someone");
        System.out.println("My favorite movie: Mission Impossible series");
        
    }
    
}