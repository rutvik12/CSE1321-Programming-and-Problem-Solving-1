// Class: CSE 1321L
// Section:09
// Term:Fall 
// Instructor:Shweta Khandal 
// Name:Rutvik Marakana 
// Lab#:Java
class Rectangle
{
   public static void main(String [] args)
    {
        int width,height,area,perimeter;
        width=4;
        height=8;
        area=width*height;
        perimeter=(2*width)+(2*height);
        System.out.println("The width:"+width);
        System.out.println("The height:"+height);
        System.out.println("The area:"+area);
        System.out.println("The perimeter:"+perimeter);
     }
}
    
         