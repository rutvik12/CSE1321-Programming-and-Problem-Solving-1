// Class: CSE 1321L
// Section:09
// Term:Fall 
// Instructor:Shweta Khandal 
// Name:Rutvik Marakana 
// Lab#:Java
 class Diamond
{
   public static void main(String [] args)
   {
       System.out.println("   *   ");
       System.out.println("  * *  ");
       System.out.println(" * * * ");
       System.out.println("* * * *");
       System.out.println(" * * * ");
       System.out.println("  * *  ");
       System.out.println("   *   ");
       
    }
}
       