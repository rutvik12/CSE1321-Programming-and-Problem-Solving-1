class PalindromicPrime
{
   public static void main(String [] args)
   {
         int total =50;
         int displayPerLine = 10;
         int count = 1;
         int number = 2;
         
        while (count <= total)
        {
              if (isPrime(number) && isPalindrome(number))
              {
                 System.out.print(number + " ");//Prints the number if it is a palindromic prime number
              
                 if (count % displayPerLine == 0)//Prints the next number on another line if condition is true
                 {
                   System.out.println();
                 } 
                count++; 
                number++;
              }
              else
              {
                number++;
              }
        }
     }


    public static boolean isPrime(int num)//Method return true if the number is prime
    {
           if (num == 2)
           {
             return true;
           }
        for (int divisor = 2; divisor <= num/2; divisor++)
        {
            if (num % divisor == 0)
            {
               return false;
            }
        }
        return (num==2 || num%2!=0);
    }
 
     
    public static boolean isPalindrome(int num)//Method return true if the number is a palindrome number
    {   int k=num;
        int test=0;
        while(num != 0)
       {
           int lastdigit=num%10;
           test=test*10+lastdigit;
           num=num/10;
       }
        return (k==test);
    }
}
